# CALL OF NARIS — UI4.1 Production Patch

Target: Unreal Engine 5.7 project at `C:\Users\Admin\NARIS`.

This package fixes the incomplete UI4 handoff by providing an executable production workflow rather than pretending binary Unreal assets exist.

## Run
Open PowerShell and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Tools\Apply-UI4_1.ps1
```

The script:
1. Validates the NARIS project and UI3 source markers.
2. Creates a timestamped backup of HUD/GameMode/config files.
3. Applies safe source/config patches only when their expected anchors exist.
4. Builds `NARISEditor` with UnrealBuildTool.
5. Packages Windows Development to `Builds\WindowsDevelopment_UI4_1`.
6. Launches the packaged `NARIS.exe`.
7. Runs log validation for `NARIS_FRONTEND READY`, `NARIS_RUNTIME_READY`, fatal errors, load failures, and Direct Play regression.

If an expected source anchor is not found, it stops without modifying that file. Use `Rollback-UI4_1.ps1` to restore the newest backup.
